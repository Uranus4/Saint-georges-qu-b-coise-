# Rewards Search Automator
<p align="center">
<img  src="https://raw.githubusercontent.com/AsoStrife/Rewards-Search-Automator/47d130ff07c6fe779984987cdcdbe747fd244ac9/img/icon128.png">
</p>


With this extension, you can automate searches on the **Bing** search engine to earn points for **Microsoft Rewards**.

This extension allows you to perform searches on both **Desktop** and **Mobile** devices.

You can customize both the time intervals between each search and the number of searches you want to perform.

It's completely free and without ads.

You can install it from the store: [Rewards Search Automator - Chrome Web Store](https://chromewebstore.google.com/u/3/detail/paohfpjfibchbhbkdnlhjpfblafifehg/preview?hl=it) or you can deploy the `.zip` package directly in your browser using Developer Mode. 

<p align="center">
<img  src="https://raw.githubusercontent.com/AsoStrife/Rewards-Search-Automator/47d130ff07c6fe779984987cdcdbe747fd244ac9/img/preview-big.png">
</p>